#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"

// Sorting prototypes
int compareByName(const void *a, const void *b);
int compareByPhone(const void *a, const void *b);
int compareByEmail(const void *a, const void *b);

void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
    loadContactsFromFile(addressBook);
    // populateAddressBook(addressBook); // Uncomment once if you need dummy data
}

void saveAndExit(AddressBook *addressBook) {
    char choice;
    printf("Do you want to save before exiting? (Y/N): ");
    scanf(" %c", &choice);
    if (choice == 'Y' || choice == 'y')
        saveContactsToFile(addressBook);

    printf("Exiting Address Book... Goodbye!\n");
    exit(0);
}

void createContact(AddressBook *addressBook) {
    if (addressBook->contactCount >= MAX_CONTACTS) {
        printf("Address book is full!\n");
        return;
    }

    Contact newContact;
    printf("\n--- Add New Contact ---\n");
    printf("Enter name: ");
    scanf(" %[^\n]", newContact.name);
    printf("Enter phone: ");
    scanf(" %[^\n]", newContact.phone);
    printf("Enter email: ");
    scanf(" %[^\n]", newContact.email);

    addressBook->contacts[addressBook->contactCount++] = newContact;
    printf("Contact added successfully!\n");
}

void searchContact(AddressBook *addressBook) {
    int choice;
    char key[50];
    int found = 0;

    if (addressBook->contactCount == 0) {
        printf("No contacts available.\n");
        return;
    }

    printf("\n--- Search Contact ---\n");
    printf("1. Search by Name\n");
    printf("2. Search by Phone Number\n");
    printf("3. Search by Email ID\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    printf("Enter search keyword: ");
    scanf(" %[^\n]", key);

    printf("\n%-4s %-20s %-15s %-25s\n", "No", "Name", "Phone", "Email");
    printf("------------------------------------------------------------\n");

    for (int i = 0; i < addressBook->contactCount; i++) {
        int match = 0;
        switch (choice) {
            case 1: if (strstr(addressBook->contacts[i].name, key)) match = 1; break;
            case 2: if (strstr(addressBook->contacts[i].phone, key)) match = 1; break;
            case 3: if (strstr(addressBook->contacts[i].email, key)) match = 1; break;
        }
        if (match) {
            printf("%-4d %-20s %-15s %-25s\n",
                   i + 1,
                   addressBook->contacts[i].name,
                   addressBook->contacts[i].phone,
                   addressBook->contacts[i].email);
            found = 1;
        }
    }

    if (!found)
        printf("No contact found matching '%s'\n", key);
}

void editContact(AddressBook *addressBook) {
    int choice;
    char key[50];
    int found = 0;

    if (addressBook->contactCount == 0) {
        printf("No contacts available to edit.\n");
        return;
    }

    printf("\n--- Edit Contact ---\n");
    printf("Edit by:\n");
    printf("1. Name\n2. Phone Number\n3. Email ID\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    printf("Enter value to search: ");
    scanf(" %[^\n]", key);

    for (int i = 0; i < addressBook->contactCount; i++) {
        int match = 0;
        switch (choice) {
            case 1: if (strcmp(addressBook->contacts[i].name, key) == 0) match = 1; break;
            case 2: if (strcmp(addressBook->contacts[i].phone, key) == 0) match = 1; break;
            case 3: if (strcmp(addressBook->contacts[i].email, key) == 0) match = 1; break;
        }

        if (match) {
            printf("Editing contact: %s\n", addressBook->contacts[i].name);
            printf("Enter new name: ");
            scanf(" %[^\n]", addressBook->contacts[i].name);
            printf("Enter new phone: ");
            scanf(" %[^\n]", addressBook->contacts[i].phone);
            printf("Enter new email: ");
            scanf(" %[^\n]", addressBook->contacts[i].email);
            printf("Contact updated successfully!\n");
            found = 1;
            break;
        }
    }

    if (!found)
        printf("No matching contact found.\n");
}

void deleteContact(AddressBook *addressBook) {
    int choice;
    char key[50];
    int found = 0;

    if (addressBook->contactCount == 0) {
        printf("No contacts available to delete.\n");
        return;
    }

    printf("\n--- Delete Contact ---\n");
    printf("Delete by:\n");
    printf("1. Name\n2. Phone Number\n3. Email ID\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    printf("Enter value to search: ");
    scanf(" %[^\n]", key);

    for (int i = 0; i < addressBook->contactCount; i++) {
        int match = 0;
        switch (choice) {
            case 1: if (strcmp(addressBook->contacts[i].name, key) == 0) match = 1; break;
            case 2: if (strcmp(addressBook->contacts[i].phone, key) == 0) match = 1; break;
            case 3: if (strcmp(addressBook->contacts[i].email, key) == 0) match = 1; break;
        }

        if (match) {
            for (int j = i; j < addressBook->contactCount - 1; j++) {
                addressBook->contacts[j] = addressBook->contacts[j + 1];
            }
            addressBook->contactCount--;
            printf("Contact deleted successfully!\n");
            found = 1;
            break;
        }
    }

    if (!found)
        printf("No matching contact found.\n");
}

void listContacts(AddressBook *addressBook, int sortCriteria) {
    if (addressBook->contactCount == 0) {
        printf("\nNo contacts available.\n");
        return;
    }

    switch (sortCriteria) {
        case 1:
            qsort(addressBook->contacts, addressBook->contactCount, sizeof(Contact), compareByName);
            break;
        case 2:
            qsort(addressBook->contacts, addressBook->contactCount, sizeof(Contact), compareByPhone);
            break;
        case 3:
            qsort(addressBook->contacts, addressBook->contactCount, sizeof(Contact), compareByEmail);
            break;
    }

    printf("\n%-4s %-20s %-15s %-25s\n", "No", "Name", "Phone", "Email");
    printf("------------------------------------------------------------\n");

    for (int i = 0; i < addressBook->contactCount; i++) {
        printf("%-4d %-20s %-15s %-25s\n",
               i + 1,
               addressBook->contacts[i].name,
               addressBook->contacts[i].phone,
               addressBook->contacts[i].email);
    }

    printf("------------------------------------------------------------\n");
    printf("Total Contacts: %d\n", addressBook->contactCount);
}

// Sorting functions
int compareByName(const void *a, const void *b) {
    return strcmp(((Contact *)a)->name, ((Contact *)b)->name);
}
int compareByPhone(const void *a, const void *b) {
    return strcmp(((Contact *)a)->phone, ((Contact *)b)->phone);
}
int compareByEmail(const void *a, const void *b) {
    return strcmp(((Contact *)a)->email, ((Contact *)b)->email);
}
