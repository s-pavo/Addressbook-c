#ifndef POPULATE_H
#define POPULATE_H

#include "contact.h"

void populateAddressBook(AddressBook *addressBook);

#endif
